# Service Discovery

## Aufgabe

Wir wollen die DNS Auflösung noch weiter betrachten.

1. Mache dazu eine DNS Abfrage für den Mysql Service Innerhalb des Wordpress Pods.
2. Welche Domains können aufeglöst werden?
3. Und welche IP erhalten wir für MySQL? Was für eine IP ist das?


## Tipps

* Kommando im Pod ausführen: `kubectl -n blog exec -it <wordpress-POD> command`

