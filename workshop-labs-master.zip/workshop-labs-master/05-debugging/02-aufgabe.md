# Pod Debuggen

Der Pod startet noch immer nicht und endet im Status `CrashLoopBackoff`.

## Aufgabe

Finde das Problem und behebe es.

