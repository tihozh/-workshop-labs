# Pod Debugging

Wir debuggen einen Pod der nicht läuft.

## Aufgabe

1. Erstelle das Deployment `crash.yaml`.

2. Der Pod startet nicht, finde heraus wieso.

3. Behebe den Fehler.


## Tipps

* Auf dem Docker Hub können öffentliche Images gesucht und gefunden werden: https://hub.docker.com/. Es können auch alle Images von einem Benutzer aufgelistet werden.
