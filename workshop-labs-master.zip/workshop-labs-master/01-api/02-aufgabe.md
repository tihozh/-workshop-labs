# API

## Aufgabe

1. Welche Optionen gibt es um einen Node anzuzeigen?

2. Wie erhalten wir das Manifest von einem bestimmten Node?
