# Externer Zugriff

Service mit NodePort


## Aufgabe

1. Wir erstellen einen zweiten Service mit einem NodePort (node-service.yaml).
2. Finde den NodePort der dem Service zugewiesen wurde.
3. Öffne den Service nun auf localhost und dem NodePort. Funktioniert der Zugriff?

