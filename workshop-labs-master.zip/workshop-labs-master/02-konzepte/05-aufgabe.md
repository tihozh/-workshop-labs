# Rollback

## Aufgabe

Rollback auf eine vorherige Version:

1. Zeige alle Revisionen des nginx Deployments an.
2. Wähle eine vorherige Version aus und führe ein Rollback durch.
3. Prüfe im Browser ob die korrekte Version deployed wurde.

## Tipps

* Benutze das Kommando `kubectl rollout --help` um alle Optionen zu sehen.


